#include "mainwidget.h"

MainWidget::MainWidget(QWidget *parent)
    : QWidget(parent)
{

    //设置鼠标和大小
    Qt::WindowFlags flags=0;
    flags |= Qt::FramelessWindowHint;
    this->setWindowFlags(flags);
    this->setFixedSize(320,240);
    QPalette pe_background;
    QColor rgb_background;
    rgb_background.setRgb(66,221,229);
    pe_background.setColor(QPalette::WindowText,Qt::green);
    this->setStyleSheet("color:yellow; background-color:rgb(15,59,92)");

    initGUI();

    insmod_moudles();
    timerButton = new QTimer(this);
    connect(timerButton, SIGNAL(timeout()), this, SLOT(Button_state()));
    connect(timerButton, SIGNAL(timeout()), this, SLOT(Button_action()));
    timerButton->setInterval(200);
    timerButton->start();


    connect(&fw,SIGNAL(switchToMainWidget()),this,SLOT(show()));
    connect(&fw,SIGNAL(switchToMainWidget()),this,SLOT(setFocus()));
    connect(&fw,SIGNAL(switchToMainWidget()),&fw,SLOT(hide()));

/*    QTimer *timer2= new QTimer(this);
//    timer2->singleShot(5000,this,SLOT(setFwVisible()));

    canRxThread = new CanReadThread();
    connect(canRxThread,SIGNAL(getSysPowerVoltage(float)),this,SLOT(setSysPower(float)));
    connect(canRxThread,SIGNAL(getForcePowerVoltage(float)),this,SLOT(setForcePower(float)));
    connect(canRxThread,SIGNAL(getIsPowerSupplyGood(QString,bool)),this,SLOT(setPowerSupplyLabel(QString,bool)));
    connect(canRxThread,SIGNAL(isLEDChanged(int,bool)),this,SLOT(setLED(int,bool)));

//    connect(canRxThread,SIGNAL(setTpwStatus(int,bool)),fw,SLOT();

    canRxThread->start(); */


    lastTimeTotal=0;
    //定时刷新运行时间
    timerForTimeUpdate= new QTimer(this);
    connect(timerForTimeUpdate,SIGNAL(timeout()),this,SLOT(timeToNowUpdate()));
    connect(timerForTimeUpdate,SIGNAL(timeout()),this,SLOT(blinkLEDRed()));

    counterforwidget = 0;
    timerForTimeUpdate->start(300);
    counterForBlink1 = 0;

    unsigned short out=0xfeff;
    writeIO(out);

    canr1counter=0;
    canr2counter=0;

    arguments1 << "can0";
    proc_canr1.start("./canread1", arguments1);
    // 等待进程启动
    if (!proc_canr1.waitForStarted())
    {
        qDebug() << "can0 read start failure.\n";
    }
    else qDebug() << "can0 read start success.\n";
    // 关闭写通道,因为没有向进程写数据,没用到
    proc_canr1.closeWriteChannel();
    connect(&proc_canr1, SIGNAL(readyRead()), this, SLOT(dataDisplay1()));

    arguments2 << "can1";
    proc_canr2.start("./canread2", arguments2);
    // 等待进程启动
    if (!proc_canr2.waitForStarted())
    {
        qDebug() << "can1 read start failure.\n";
    }
    else qDebug() << "can1 read start success.\n";
    // 关闭写通道,因为没有向进程写数据,没用到
    proc_canr2.closeWriteChannel();
    connect(&proc_canr2, SIGNAL(readyRead()), this, SLOT(dataDisplay2()));

    arguments3 << "can0";
    proc_cans1.start("./cansend1",arguments3);
    if (!proc_cans1.waitForStarted())
    {
        qDebug() << "can0 send start failure.\n";
    }
    else qDebug() << "can0 send start success.\n";

/*    arguments4 << "can1" <<"0x45"<<"0x82"<<"0x83"<<"0x94";
    proc_cans2.start("./cansend2",arguments4);
    if (!proc_cans2.waitForStarted())
    {
        qDebug() << "can1 send start failure.\n";
    }
    else qDebug() << "can1 send start success.\n";
    QByteArray can2ba("0x22");
    proc_cans2.write(can2ba);*/

    connect(this,SIGNAL(can1_send_data(QStringList)),this,SLOT(can1_send(QStringList)));

}


void MainWidget::initGUI()
{


    QPalette pe;
    pe.setColor(QPalette::WindowText,Qt::blue);
    QPalette pe2;
    pe2.setColor(QPalette::WindowText,Qt::black);


    sysPowerLabel= new QLabel(this);
    sysPowerLabel->setText("系统电源");
    sysPowerLabel->setPalette(pe);
    sysPowerLabel->setAlignment(Qt::AlignCenter);
    sysPowerLabel->setGeometry(5,42,150,20);

     QFont font_power;
    font_power.setFamily("wenquanyi");
    font_power.setPointSize(80);

    sysPowerStatus = new QLabel(this);
    sysPowerStatus->setText("0 V");
    sysPowerStatus->setStyleSheet("color:white; background-color:gray");
    sysPowerStatus->setFont(font_power);
    sysPowerStatus->setAlignment(Qt::AlignCenter);
    sysPowerStatus->setGeometry(5,10,150,30);

    forcePowerLabel= new QLabel(this);
    forcePowerLabel->setText("动力电源");
    forcePowerLabel->setPalette(pe);
    forcePowerLabel->setGeometry(165,42,150,20);
    forcePowerLabel->setAlignment(Qt::AlignCenter);

    forcePowerStatus = new QLabel(this);
    forcePowerStatus->setText("0 V");
    forcePowerStatus->setStyleSheet("color:white; background-color:gray");
    forcePowerStatus->setFont(font_power);
    forcePowerStatus->setAlignment(Qt::AlignCenter);
    forcePowerStatus->setGeometry(165,10,150,30);

    ammunitionBox= new QLabel(this);
    ammunitionBox->setText("弹箱");
    ammunitionBox->setPalette(pe);
    ammunitionBox->setGeometry(70,105,30,15);
    ammunitionBox->setAlignment(Qt::AlignLeft);


    ammunitionBoxStatus1= new QLabel(this);
    ammunitionBoxStatus1->setText("有箱");
    ammunitionBoxStatus1->setStyleSheet("color:rgb(242,210,40)");
    ammunitionBoxStatus1->setGeometry(25,80,30,20);
    ammunitionBoxStatus1->setAlignment(Qt::AlignCenter);

    ammunitionBoxStatus2= new QLabel(this);
    ammunitionBoxStatus2->setText("锁紧");
    ammunitionBoxStatus2->setStyleSheet("color:rgb(242,210,40)");
    ammunitionBoxStatus2->setGeometry(55,80,30,20);
    ammunitionBoxStatus2->setAlignment(Qt::AlignCenter);

    ammunitionBoxStatus3= new QLabel(this);
    ammunitionBoxStatus3->setText("解脱");
    ammunitionBoxStatus3->setStyleSheet("color:rgb(242,210,40)");
    ammunitionBoxStatus3->setGeometry(85,80,30,20);
    ammunitionBoxStatus3->setAlignment(Qt::AlignCenter);

    ammunitionBoxStatus4= new QLabel(this);
    ammunitionBoxStatus4->setText("故障");
    ammunitionBoxStatus4->setStyleSheet("color:rgb(242,210,40)");
    ammunitionBoxStatus4->setGeometry(115,80,30,20);
    ammunitionBoxStatus4->setAlignment(Qt::AlignCenter);


    electricConnector= new QLabel(this);
    electricConnector->setText("电连接器");
    electricConnector->setPalette(pe);
    electricConnector->setGeometry(210,105,60,15);
    electricConnector->setAlignment(Qt::AlignLeft);

    electricConnectorStatus1= new QLabel(this);
    electricConnectorStatus1->setText("插接");
    electricConnectorStatus1->setStyleSheet("color:rgb(242,210,40)");
    electricConnectorStatus1->setGeometry(190,80,30,20);
    electricConnectorStatus1->setAlignment(Qt::AlignCenter);

    electricConnectorStatus2= new QLabel(this);
    electricConnectorStatus2->setText("解脱");
    electricConnectorStatus2->setStyleSheet("color:rgb(242,210,40)");
    electricConnectorStatus2->setGeometry(220,80,30,20);
    electricConnectorStatus2->setAlignment(Qt::AlignCenter);

    electricConnectorStatus3= new QLabel(this);
    electricConnectorStatus3->setText("故障");
    electricConnectorStatus3->setStyleSheet("color:rgb(242,210,40)");
    electricConnectorStatus3->setGeometry(250,80,30,20);
    electricConnectorStatus3->setAlignment(Qt::AlignCenter);

    marchFixture= new QLabel(this);
    marchFixture->setText("行军固定器");
    marchFixture->setPalette(pe);
    marchFixture->setGeometry(30,163,80,20);
    marchFixture->setAlignment(Qt::AlignCenter);

    marchFixtureStatus1= new QLabel(this);
    marchFixtureStatus1->setText("锁紧");
    marchFixtureStatus1->setStyleSheet("color:rgb(242,210,40)");
    marchFixtureStatus1->setGeometry(25,140,30,20);
    marchFixtureStatus1->setAlignment(Qt::AlignCenter);

    marchFixtureStatus2= new QLabel(this);
    marchFixtureStatus2->setText("解脱");
    marchFixtureStatus2->setStyleSheet("color:rgb(242,210,40)");
    marchFixtureStatus2->setGeometry(55,140,30,20);
    marchFixtureStatus2->setAlignment(Qt::AlignCenter);

    marchFixtureStatus3= new QLabel(this);
    marchFixtureStatus3->setText("故障");
    marchFixtureStatus3->setStyleSheet("color:rgb(242,210,40)");
    marchFixtureStatus3->setGeometry(85,140,30,20);
    marchFixtureStatus3->setAlignment(Qt::AlignCenter);

    gasPressure= new QLabel(this);
    gasPressure->setText("气源压力");
    gasPressure->setPalette(pe);
    gasPressure->setGeometry(140,163,50,20);
    gasPressure->setAlignment(Qt::AlignCenter);

    gasPressureStatus1= new QLabel(this);
    gasPressureStatus1->setText("正常");
    gasPressureStatus1->setStyleSheet("color:rgb(242,210,40)");
    gasPressureStatus1->setGeometry(135,140,30,20);
    gasPressureStatus1->setAlignment(Qt::AlignCenter);

    gasPressureStatus2= new QLabel(this);
    gasPressureStatus2->setText("过低");
    gasPressureStatus2->setStyleSheet("color:rgb(242,210,40)");
    gasPressureStatus2->setGeometry(165,140,30,20);
    gasPressureStatus2->setAlignment(Qt::AlignCenter);

    shootRange= new QLabel(this);
    shootRange->setText("射界");
    shootRange->setPalette(pe);
    shootRange->setGeometry(225,163,50,20);
    shootRange->setAlignment(Qt::AlignCenter);

    shootRangeStatus1= new QLabel(this);
    shootRangeStatus1->setText("允许");
    shootRangeStatus1->setStyleSheet("color:rgb(242,210,40)");
    shootRangeStatus1->setGeometry(220,140,30,20);
    shootRangeStatus1->setAlignment(Qt::AlignCenter);

    shootRangeStatus2= new QLabel(this);
    shootRangeStatus2->setText("禁止");
    shootRangeStatus2->setStyleSheet("color:rgb(242,210,40)");
    shootRangeStatus2->setGeometry(250,140,30,20);
    shootRangeStatus2->setAlignment(Qt::AlignCenter);

    instruction= new QLabel(this);
    instruction->setText("  按“功能”键可\n进入功能选择界面");
    instruction->setPalette(pe2);
    instruction->setGeometry(30,200,110,30);
    instruction->setAlignment(Qt::AlignLeft);
//    instruction->setStyleSheet("color:#B4B834");

    powerSupplyLabel= new QLabel(this);
    powerSupplyLabel->setPalette(pe2);
    powerSupplyLabel->setGeometry(170,190,110,40);
    powerSupplyLabel->setAlignment(Qt::AlignLeft);

    timeToNowLabel= new QLabel(this);
    timeToNowLabel->setPalette(pe2);
    timeToNowUpdate();
    timeToNowLabel->setGeometry(170,206,140,27);
    timeToNowLabel->setAlignment(Qt::AlignLeft);
//  timeToNowLabel->setStyleSheet("color:#B4B834");

    // 用于显示 LED 灯

    pen.setColor(Qt::black);
    pen.setWidth(0.35);
    pen.setCapStyle(Qt::RoundCap);
    pen.setStyle(Qt::SolidLine);
    penGreen.setColor(Qt::green);
    penGreen.setWidth(0.35);
    penGreen.setCapStyle(Qt::RoundCap);
    penGreen.setStyle(Qt::SolidLine);
    penRed.setColor(Qt::red);
    penRed.setWidth(0.35);
    penRed.setCapStyle(Qt::RoundCap);
    penRed.setStyle(Qt::SolidLine);
    brushRed.setColor(Qt::red);
    brushRed.setStyle(Qt::SolidPattern);
    brushGreen.setColor(Qt::green);
    brushGreen.setStyle(Qt::SolidPattern);
    QColor rgb_background;
    rgb_background.setRgb(15,59,92);
    brushBlue.setColor(rgb_background); //与背景色相同
    brushBlue.setStyle(Qt::SolidPattern);
    ledScene1 = new QGraphicsScene(this);
    ledScene2 = new QGraphicsScene(this);
    ledScene3 = new QGraphicsScene(this);
    ledScene4 = new QGraphicsScene(this);
    ledScene5 = new QGraphicsScene(this);

    ledView1 = new QGraphicsView(this);
    ledView1->setGeometry(0,68,150,13);
    pe2.setColor(QPalette::WindowText,Qt::transparent);
    ledView1->setPalette(pe2);
    ledView1->setFrameStyle(0); //不显示边框
    ledView1->setScene(ledScene1);
    ledView1->setSceneRect(0,0,150,13);
    ledView1->setStyleSheet("background:transparent");

    ledView2 = new QGraphicsView(this);
    ledView2->setGeometry(160,68,150,13);
    ledView2->setPalette(pe2);
    ledView2->setFrameStyle(0); //不显示边框
    ledView2->setScene(ledScene2);
    ledView2->setSceneRect(0,0,150,13);
    ledView2->setStyleSheet("background:transparent");

    ledView3 = new QGraphicsView(this);
    ledView3->setGeometry(0,126,110,13);
    ledView3->setPalette(pe2);
    ledView3->setFrameStyle(0); //不显示边框
    ledView3->setScene(ledScene3);
    ledView3->setSceneRect(0,0,100,13);
    ledView3->setStyleSheet("background:transparent");

    ledView4 = new QGraphicsView(this);
    ledView4->setGeometry(120,126,80,13);
    ledView4->setPalette(pe2);
    ledView4->setFrameStyle(0); //不显示边框
    ledView4->setScene(ledScene4);
    ledView4->setSceneRect(0,0,30,13);
    ledView4->setStyleSheet("background:transparent");

    ledView5 = new QGraphicsView(this);
    ledView5->setGeometry(180,126,100,13);
    ledView5->setPalette(pe2);
    ledView5->setFrameStyle(0); //不显示边框
    ledView5->setScene(ledScene5);
    ledView5->setSceneRect(0,0,30,13);
    ledView5->setStyleSheet("background:transparent");

    ellipse1 = new QGraphicsEllipseItem();
    ellipse1->setRect(35,2,10,10);
    ellipse1->setPen(pen);
    ellipse1->setBrush(brushGreen);

    ellipse2 = new QGraphicsEllipseItem();
    ellipse2->setRect(65,2,10,10);
    ellipse2->setPen(pen);
    ellipse2->setBrush(brushGreen);

    ellipse3 = new QGraphicsEllipseItem();
    ellipse3->setRect(95,2,10,10);
    ellipse3->setPen(pen);
    ellipse3->setBrush(brushGreen);

    ellipse4 = new QGraphicsEllipseItem();
    ellipse4->setRect(125,2,10,10);
    ellipse4->setPen(pen);
    ellipse4->setBrush(brushRed);

    ellipse5 = new QGraphicsEllipseItem();
    ellipse5->setRect(40,2,10,10);
    ellipse5->setPen(pen);
    ellipse5->setBrush(brushGreen);

    ellipse6 = new QGraphicsEllipseItem();
    ellipse6->setRect(70,2,10,10);
    ellipse6->setPen(pen);
    ellipse6->setBrush(brushGreen);

    ellipse7 = new QGraphicsEllipseItem();
    ellipse7->setRect(100,2,10,10);
    ellipse7->setPen(pen);
    ellipse7->setBrush(brushRed);

    ellipse8 = new QGraphicsEllipseItem();
    ellipse8->setRect(30,2,10,10);
    ellipse8->setPen(pen);
    ellipse8->setBrush(brushGreen);

    ellipse9 = new QGraphicsEllipseItem();
    ellipse9->setRect(60,2,10,10);
    ellipse9->setPen(pen);
    ellipse9->setBrush(brushGreen);

    ellipse10 = new QGraphicsEllipseItem();
    ellipse10->setRect(90,2,10,10);
    ellipse10->setPen(pen);
    ellipse10->setBrush(brushRed);

    ellipse11 = new QGraphicsEllipseItem();
    ellipse11->setRect(0,2,10,10);
    ellipse11->setPen(pen);
    ellipse11->setBrush(brushGreen);

    ellipse12 = new QGraphicsEllipseItem();
    ellipse12->setRect(30,2,10,10);
    ellipse12->setPen(pen);
    ellipse12->setBrush(brushRed);

    ellipse13 = new QGraphicsEllipseItem();
    ellipse13->setRect(15,2,10,10);
    ellipse13->setPen(pen);
    ellipse13->setBrush(brushGreen);

    ellipse14 = new QGraphicsEllipseItem();
    ellipse14->setRect(45,2,10,10);
    ellipse14->setPen(pen);
    ellipse14->setBrush(brushRed);

//    for(int i=1;i<15;i++)  setLED(i,true);

}


void MainWidget::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QColor line;
    line.setRgb(41,182,23);
    painter.setPen(QPen(Qt::gray,3,Qt::SolidLine,Qt::RoundCap));

    // line to seperate different parts
    painter.drawLine(1,1,317,1);    // horizontal
    painter.drawLine(1,236,317,236);    // horizontal
    painter.drawLine(1,65,320,65);    // horizontal
    painter.drawLine(1,125,320,125);  // horizontal
    painter.drawLine(1,185,320,185);  // horizontal
    painter.drawLine(160,68,160,122);  // vertical
    painter.drawLine(160,188,160,235); // vertical
    painter.drawLine(120,128,120,182); // vertical
    painter.drawLine(202,128,202,182); // vertical
    painter.drawLine(1,0,1,237); // vertical
    painter.drawLine(319,0,319,237); // vertical

}

void MainWidget::timeToNowUpdate()
{

    QDateTime timeNow = QDateTime::currentDateTime();
    int days = timeNow.date().day()-timeStart.date().day();
    int hours = timeNow.time().hour()-timeStart.time().hour();
    int minutes =  timeNow.time().minute()-timeStart.time().minute();
    int seconds =  timeNow.time().second()-timeStart.time().second();
    bool ok;
    timeTotal = timePast.toInt(&ok,10)+((days*24 + hours)*60 + minutes)*60 + seconds;
    int hResult = timeTotal/3600;
    int mResult = (timeTotal-hResult*3600)/60;
    int sResult = timeTotal-hResult*3600-mResult*60;
    QString hh = QString::number(hResult,10);
    QString mm = QString::number(mResult,10);
    QString ss = QString::number(sResult,10);
    timeToNowLabel->setText("系统累计运行时间：\n"+hh+" 时 "+mm+" 分 "+ss+" 秒");

    if((timeTotal%600==0)&&(timeTotal!=lastTimeTotal))   // 隔一段时间写入一次
    {
        QFile file("electime.dat");
        /* 打开文件，写入已运行总时间 */
        if(file.open(QIODevice::WriteOnly))
        {
            QDataStream out(&file);
            out.setVersion(QDataStream::Qt_4_7);
            out << QString::number(timeTotal,10);
            lastTimeTotal = timeTotal;

            qDebug("write and close electime.dat done.");
        }
        else
        {
            qDebug("open electime.dat error.");// 报错
        }
        if(file.isOpen())
                file.close();
    }
}

void MainWidget::keyPressEvent(QKeyEvent *event)
{
/*    switch (event->key()) {
    case 0xfffe:
        sysPowerStatus->setText("up键");
    case 0xfffd:
        sysPowerStatus->setText("down键");
    case 0xfffb:
        sysPowerStatus->setText("left键");
    case 0xfff7:
        sysPowerStatus->setText("right键");
    case 0xffef:
        sysPowerStatus->setText("功能键");
    case 0xffdf:
        sysPowerStatus->setText("确认键");
    case 0xffbf:
        sysPowerStatus->setText("用炮键");
    case 0xff7f:
        sysPowerStatus->setText("收炮键");
    default:
        break;
   }
*/
}

void MainWidget::setLED(int index,bool isActive)
{
    isLEDActive[index]=isActive;
    if(isActive) enableLED(index);
    else disableLED(index);
}

void MainWidget::enableLED(int i)
{
    switch(i)
    {
        case 1:
            ledScene1->addItem(ellipse1); break;
        case 2:
            ledScene1->addItem(ellipse2); break;
        case 3:
            ledScene1->addItem(ellipse3); break;
        case 4:
            ledScene1->addItem(ellipse4); break;
        case 5:
            ledScene2->addItem(ellipse5); break;
        case 6:
            ledScene2->addItem(ellipse6); break;
        case 7:
            ledScene2->addItem(ellipse7); break;
        case 8:
            ledScene3->addItem(ellipse8); break;
        case 9:
            ledScene3->addItem(ellipse9); break;
        case 10:
            ledScene3->addItem(ellipse10); break;
        case 11:
            ledScene4->addItem(ellipse11); break;
        case 12:
            ledScene4->addItem(ellipse12); break;
        case 13:
            ledScene5->addItem(ellipse13); break;
        case 14:
            ledScene5->addItem(ellipse14); break;
    }
}

void MainWidget::disableLED(int i)
{
    switch(i)
    {
    case 1:
        ledScene1->removeItem(ellipse1); break;
    case 2:
        ledScene1->removeItem(ellipse2); break;
    case 3:
        ledScene1->removeItem(ellipse3); break;
    case 4:
        ledScene1->removeItem(ellipse4); break;
    case 5:
        ledScene2->removeItem(ellipse5); break;
    case 6:
        ledScene2->removeItem(ellipse6); break;
    case 7:
        ledScene2->removeItem(ellipse7); break;
    case 8:
        ledScene3->removeItem(ellipse8); break;
    case 9:
        ledScene3->removeItem(ellipse9); break;
    case 10:
        ledScene3->removeItem(ellipse10); break;
    case 11:
        ledScene4->removeItem(ellipse11); break;
    case 12:
        ledScene4->removeItem(ellipse12); break;
    case 13:
        ledScene5->removeItem(ellipse13); break;
    case 14:
        ledScene5->removeItem(ellipse14); break;
    }
}


void MainWidget::blinkLEDRed()
{

/*    if(counterForBlink1==0)
        {
            if(isLEDActive[4]) enableLED(4);
            if(isLEDActive[7]) enableLED(7);
            if(isLEDActive[10]) enableLED(10);
            if(isLEDActive[12]) enableLED(12);
            if(isLEDActive[14]) enableLED(14);
            counterForBlink1++;
        }
     else
        {
            disableLED(4);
            disableLED(7);
            disableLED(10);
            disableLED(12);
            disableLED(14);
            counterForBlink1=0;
        }
*/
}

void MainWidget::setSysPower(float voltage)
{
    voltage = ((float)((int)(voltage*100)))/100;  //保留两位小数
    QString data = QString("%1").arg(voltage);
     sysPowerStatus->setText(data+" V");
}

void MainWidget::setForcePower(float voltage)
{
    voltage = ((float)((int)(voltage*100)))/100;  //保留两位小数
    QString data = QString("%1").arg(voltage);
     forcePowerStatus->setText(data+" V");
}

void MainWidget::setPowerSupplyLabel(QString s,bool isGood)
{
    powerSupplyLabel->setText(s);
    if(isGood) powerSupplyLabel->setStyleSheet("color:rgb(0,255,0)");
    else powerSupplyLabel->setStyleSheet("color:red");
}

void MainWidget::insmod_moudles()
{
    fd = ::open("/dev/sam9g45", O_RDWR|O_NONBLOCK);
    if (fd < 0) {
       qDebug("insmod moudles error.\n");;
    }

    qDebug("insmod moudles ok.\n");
}

void MainWidget::Button_state()
{
    buf_read = 0;

    data_to_kernel.offset = 16;
    data_to_kernel.dataBuf = 0;

    ret = ioctl(fd, 3, (unsigned long)&data_to_kernel);
    if(ret < 0) {
        //QMessageBox::information(&w, "error", "ioctl");
        return;
    }
    int ret = read(fd, &buf_read, 2);

    if(ret < 0){
        //QMessageBox::information(&w, "error", "read");
        return;
    }
    //qDebug("buf = 0x%x from main", buf_read);

    QByteArray ba;
    ba.append(QString::number(buf_read,2));  // 转2进制
    k = ba.right(12);   // 截取后12位（对应面板上的8个按键和4个开关）
    //qDebug()<<k;
    //qDebug()<<nowWidgetEnabled;
    instruction->setText(QString::number(buf_read));//

}

void MainWidget::Button_action()
{
  if(nowWidgetEnabled==0)
  {
    if(k.at(K_FUNC)=='0')
    {
       showFw();
       //qDebug("buf = 0x%x", buf_read);
    }
    if(k.at(K_ALARM)=='0'&& outState.at(OUT_ALARM)=='0')   // 如果故障报警按键被按下，则蜂鸣器停止，LED灭
    {
       writeOutDev(OUT_ALARM,false);
       writeOutDev(OUT_ALARM_LED,false);
       //qDebug()<<outState;
    }
    if(k.at(K_USE)=='0'&& outState.at(OUT_ALARM)=='1')
    {
       writeOutDev(OUT_ALARM,true);
       writeOutDev(OUT_ALARM_LED,true);
       //qDebug()<<outState;
    }
  }
}
void MainWidget::writeOutDev(int index, bool enable)
{
    QByteArray ba0("0");
    QByteArray ba1("1");
    if(enable) outState.replace(index,1,ba0);
    else outState.replace(index,1,ba1);

    QByteArray ba2("111111111111");
    ba2.insert(4,outState);
    // qDebug()<<ba2;
    bool ok;
    writeIO(ba2.toUShort(&ok,2));
}

void MainWidget::writeIO(unsigned short data)
{
    pdata data_write;
    data_write.offset = 17;
    data_write.dataBuf = data;

    ret = ioctl(fd, 1, (unsigned long)&data_write);

    if(ret < 0) {
        qDebug("writeIO ERROR.");
        return;
    }
    else qDebug("writeIO OK. data=0x%x",data);

}

void MainWidget::dataDisplay1()
{
    canr1counter++;
    QByteArray procOutput1;
    procOutput1 = proc_canr1.readAll();
    marchFixture->setText(procOutput1.data());
    gasPressure->setText("A "+QString::number(canr1counter,10));
    // 输出读到的数据
    //qDebug() << procOutput1.data();
    QStringList argument;
    argument<< "can1" <<"0x45"<<"0x82"<<"0x83"<<"0x94";
    emit(can1_send_data(argument));
}
void MainWidget::dataDisplay2()
{
    canr2counter++;
    QByteArray procOutput2;
    procOutput2 = proc_canr2.readAll();
    sysPowerLabel->setText(procOutput2.data());
    forcePowerLabel->setText("B "+QString::number(canr2counter,10));
    // 输出读到的数据
    //qDebug() << procOutput2.data();
}

void MainWidget::can1_send(QStringList sl)
{
       proc_cans2.start("./cansend2",sl);
       if (!proc_cans2.waitForStarted())
       {
           qDebug() << "can1 send start failure.\n";
       }
       //else qDebug() << "can1 send start success.\n";
       proc_cans2.terminate();
}

void MainWidget::can2_send(QStringList)
{

}

void MainWidget::showFw()
{
    fw.show();
    this->hide();
    fw.initFocus();
    nowWidgetEnabled=1;
}

MainWidget::~MainWidget()
{

}
