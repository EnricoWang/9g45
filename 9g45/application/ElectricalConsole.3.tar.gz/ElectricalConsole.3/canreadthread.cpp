#include "canreadthread.h"


CanReadThread::CanReadThread(QObject *parent)
    :QThread(parent)
{

    sysPowerVoltage=0;
    forcePowerVoltage=0;
    for(int i=0;i<15;i++) isLEDActive[i]=false;       // 1-14存状态，0不用
    powerSupplyStatus=" ";  // 显示供电状态处的文字
    isPowerSupplyGood=true;     // 供电是否正常
    stopped = false;
}

void CanReadThread::run()
{
    //QTimer *timer = new QTimer(this);
    //connect(timer,SIGNAL(timeout()),this,SLOT(readCAN()));
    //timer->start(100);
    /* 从CAN总线读取数据 */
    // TODO
    // ...............
    // ...............
    sysPowerVoltage = 28.023;
    forcePowerVoltage = 56.23;
    isPowerSupplyGood =true;
    powerSupplyStatus ="供电正常";

    emit isLEDChanged(2,true);  //LED灯状态发生改变
    emit isLEDChanged(12,true);
    emit isLEDChanged(14,true);
    emit isLEDChanged(7,true);
    //emit isLEDChanged(10,true);
    emit isLEDChanged(4,true);
    emit isLEDChanged(6,true);
    emit isLEDChanged(8,true);
    emit getSysPowerVoltage(sysPowerVoltage);
    emit getForcePowerVoltage(forcePowerVoltage);
    emit getIsPowerSupplyGood(powerSupplyStatus,isPowerSupplyGood);

}


void CanReadThread::stop()
{
    stopped = true;
}


