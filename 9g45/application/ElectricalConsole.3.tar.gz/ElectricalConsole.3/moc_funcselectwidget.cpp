/****************************************************************************
** Meta object code from reading C++ file 'funcselectwidget.h'
**
** Created: Tue Oct 13 16:00:30 2015
**      by: The Qt Meta Object Compiler version 62 (Qt 4.7.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "funcselectwidget.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'funcselectwidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.7.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_funcSelectWidget[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
      16,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: signature, parameters, type, tag, flags
      18,   17,   17,   17, 0x05,
      39,   17,   17,   17, 0x05,
      63,   17,   17,   17, 0x05,

 // slots: signature, parameters, type, tag, flags
      84,   17,   17,   17, 0x0a,
     100,   17,   17,   17, 0x0a,
     114,   17,   17,   17, 0x0a,
     125,   17,   17,   17, 0x0a,
     136,   17,   17,   17, 0x0a,
     147,   17,   17,   17, 0x0a,
     158,   17,   17,   17, 0x0a,
     169,   17,   17,   17, 0x0a,
     180,   17,   17,   17, 0x0a,
     191,   17,   17,   17, 0x0a,
     202,   17,   17,   17, 0x0a,
     213,   17,   17,   17, 0x0a,
     225,   17,   17,   17, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_funcSelectWidget[] = {
    "funcSelectWidget\0\0switchToMainWidget()\0"
    "switchToTpwWidget(bool)\0setSubTitle(QString)\0"
    "Button_action()\0dataDisplay()\0showSub1()\0"
    "showSub2()\0showSub3()\0showSub4()\0"
    "showSub5()\0showSub6()\0showSub7()\0"
    "showSub8()\0showSub9()\0showSub10()\0"
    "showSub11()\0"
};

const QMetaObject funcSelectWidget::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_funcSelectWidget,
      qt_meta_data_funcSelectWidget, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &funcSelectWidget::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *funcSelectWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *funcSelectWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_funcSelectWidget))
        return static_cast<void*>(const_cast< funcSelectWidget*>(this));
    return QWidget::qt_metacast(_clname);
}

int funcSelectWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: switchToMainWidget(); break;
        case 1: switchToTpwWidget((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 2: setSubTitle((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: Button_action(); break;
        case 4: dataDisplay(); break;
        case 5: showSub1(); break;
        case 6: showSub2(); break;
        case 7: showSub3(); break;
        case 8: showSub4(); break;
        case 9: showSub5(); break;
        case 10: showSub6(); break;
        case 11: showSub7(); break;
        case 12: showSub8(); break;
        case 13: showSub9(); break;
        case 14: showSub10(); break;
        case 15: showSub11(); break;
        default: ;
        }
        _id -= 16;
    }
    return _id;
}

// SIGNAL 0
void funcSelectWidget::switchToMainWidget()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}

// SIGNAL 1
void funcSelectWidget::switchToTpwWidget(bool _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void funcSelectWidget::setSubTitle(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
QT_END_MOC_NAMESPACE
