#include "funcselectwidget.h"

funcSelectWidget::funcSelectWidget(QWidget *parent) : QWidget(parent)
{
    //设置鼠标和大小
    Qt::WindowFlags flags=0;
    flags |= Qt::FramelessWindowHint;
    this->setWindowFlags(flags);
    this->setFixedSize(320,240);
    this->setStyleSheet("color:yellow; background-color:rgb(15,59,92)");
    this->setFocusPolicy(Qt::StrongFocus);

    fw_counter=0;
    initGUI();
/*
    connect(btn1,SIGNAL(pressed()),SLOT(showSub1()));
    connect(btn2,SIGNAL(pressed()),SLOT(showSub2()));
    connect(btn3,SIGNAL(pressed()),SLOT(showSub3()));
    connect(btn4,SIGNAL(pressed()),SLOT(showSub4()));
    connect(btn5,SIGNAL(pressed()),SLOT(showSub5()));
    connect(btn6,SIGNAL(pressed()),SLOT(showSub6()));
    connect(btn7,SIGNAL(pressed()),SLOT(showSub7()));
    connect(btn8,SIGNAL(pressed()),SLOT(showSub8()));
    connect(btn9,SIGNAL(pressed()),SLOT(showSub9()));
    connect(btn10,SIGNAL(pressed()),SLOT(showSub10()));
    connect(btn11,SIGNAL(pressed()),SLOT(showSub11()));
*/

    connect(&tpw,SIGNAL(switchToFwWidget()),this,SLOT(show()));
    connect(&radio,SIGNAL(switchToFwWidget()),this,SLOT(show()));
    connect(&control,SIGNAL(switchToFwWidget()),this,SLOT(show()));
    connect(&beidou,SIGNAL(switchToFwWidget()),this,SLOT(show()));
    connect(&oxygen,SIGNAL(switchToFwWidget()),this,SLOT(show()));
    connect(&wind,SIGNAL(switchToFwWidget()),this,SLOT(show()));
    connect(&radar,SIGNAL(switchToFwWidget()),this,SLOT(show()));
    connect(&firer,SIGNAL(switchToFwWidget()),this,SLOT(show()));
    connect(&elecctl,SIGNAL(switchToFwWidget()),this,SLOT(show()));
    connect(&servo,SIGNAL(switchToFwWidget()),this,SLOT(show()));
    connect(&power,SIGNAL(switchToFwWidget()),this,SLOT(show()));

/*        connect(&tpw,SIGNAL(switchToFwWidget()),&tpw,SLOT(hide()));
        connect(&radio,SIGNAL(switchToFwWidget()),&radio,SLOT(hide()));
        connect(&control,SIGNAL(switchToFwWidget()),&control,SLOT(hide()));
        connect(&beidou,SIGNAL(switchToFwWidget()),&beidou,SLOT(hide()));
        connect(&oxygen,SIGNAL(switchToFwWidget()),&oxygen,SLOT(hide()));
        connect(&wind,SIGNAL(switchToFwWidget()),&wind,SLOT(hide()));
        connect(&radar,SIGNAL(switchToFwWidget()),&radar,SLOT(hide()));
        connect(&firer,SIGNAL(switchToFwWidget()),&firer,SLOT(hide()));
        connect(&elecctl,SIGNAL(switchToFwWidget()),&elecctl,SLOT(hide()));
        connect(&servo,SIGNAL(switchToFwWidget()),&servo,SLOT(hide()));
        connect(&power,SIGNAL(switchToFwWidget()),&power,SLOT(hide()));
*/
    fwTimerButton = new QTimer(this);
    connect(fwTimerButton, SIGNAL(timeout()), this, SLOT(Button_action()));
    fwTimerButton->start(200);
}

void funcSelectWidget::initGUI()
{
    title= new QLabel(this);
    title->setText("功能选择");
    title->setAlignment(Qt::AlignCenter);
    title->setGeometry(111,7,100,20);
    title->setFocusPolicy(Qt::NoFocus);

    QColor rgb;
    rgb.setRgb(209,212,152);
    QPalette pe;
    pe.setColor(QPalette::WindowText,Qt::gray);

    btn1= new QPushButton(this);
    btn1->setText("炮长终端");
    btn1->setGeometry(5,50,70,30);
    btn1->setStyleSheet("background:#007503");
    btn1->setFocusPolicy(Qt::StrongFocus);
    btn2= new QPushButton(this);
    btn2->setText("电台");
    btn2->setGeometry(85,50,70,30);
    btn2->setStyleSheet("background:#007503");
    btn2->setFocusPolicy(Qt::StrongFocus);
    btn3= new QPushButton(this);
    btn3->setText("通控");
    btn3->setGeometry(165,50,70,30);
    btn3->setStyleSheet("background:#007503");
    btn3->setFocusPolicy(Qt::StrongFocus);
    btn4= new QPushButton(this);
    btn4->setText("北斗用户机");
    btn4->setGeometry(245,50,70,30);
    btn4->setStyleSheet("background:#007503");
    btn4->setFocusPolicy(Qt::StrongFocus);
    btn5= new QPushButton(this);
    btn5->setText("制氧装置");
    btn5->setGeometry(5,100,70,30);
    btn5->setStyleSheet("background:#007503");
    btn5->setFocusPolicy(Qt::StrongFocus);
    btn6= new QPushButton(this);
    btn6->setText("地面测风");
    btn6->setGeometry(85,100,70,30);
    btn6->setStyleSheet("background:#007503");
    btn6->setFocusPolicy(Qt::StrongFocus);
    btn7= new QPushButton(this);
    btn7->setText("测风雷达");
    btn7->setGeometry(165,100,70,30);
    btn7->setStyleSheet("background:#007503");
    btn7->setFocusPolicy(Qt::StrongFocus);
    btn8= new QPushButton(this);
    btn8->setText("装定发火器");
    btn8->setGeometry(245,100,70,30);
    btn8->setStyleSheet("background:#007503");
    btn8->setFocusPolicy(Qt::StrongFocus);
    btn9= new QPushButton(this);
    btn9->setText("电控箱");
    btn9->setGeometry(5,150,70,30);
    btn9->setStyleSheet("background:#007503");
    btn9->setFocusPolicy(Qt::StrongFocus);
    btn10= new QPushButton(this);
    btn10->setText("随动");
    btn10->setGeometry(85,150,70,30);
    btn10->setStyleSheet("background:#007503");
    btn10->setFocusPolicy(Qt::StrongFocus);
    btn11= new QPushButton(this);
    btn11->setText("动力电源箱");
    btn11->setGeometry(165,150,70,30);
    btn11->setStyleSheet("background:#007503");
    btn11->setFocusPolicy(Qt::StrongFocus);

    instruction= new QLabel(this);
    instruction->setText("  按“左”、“右”、“下”移动光标，按“确认”\n进入相应界面，按“上”返回主界面");
    instruction->setGeometry(25,200,280,35);
    instruction->setAlignment(Qt::AlignLeft);
    instruction->setFocusPolicy(Qt::NoFocus);
 //   instruction->setStyleSheet("color:#B4B834");
}

void funcSelectWidget::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QColor line;
    line.setRgb(41,182,23);
    painter.setPen(QPen(Qt::gray,3,Qt::SolidLine,Qt::RoundCap));

    // line to seperate different parts
    painter.drawLine(1,1,317,1);    // horizontal
    painter.drawLine(1,236,317,236);    // horizontal
    painter.drawLine(1,35,320,35);    // horizontal
    painter.drawLine(1,193,320,193);  // horizontal
    painter.drawLine(1,0,1,237); // vertical
    painter.drawLine(319,0,319,237); // vertical
}

void funcSelectWidget::initFocus()
{
    this->setFocus();
    fw_counter=0;
}

void funcSelectWidget::showSub1()
{
    tpw.setTitle(QString("炮长终端供电"));
    tpw.show();
    tpw.initFocus();
    nowWidgetEnabled=2;
}
void funcSelectWidget::showSub2()
{
    radio.setTitle(QString("电台供电"));
    radio.show();
    radio.initFocus();
    nowWidgetEnabled=3;
}
void funcSelectWidget::showSub3()
{
    control.setTitle(QString("通控供电"));
    control.show();
    control.initFocus();
    nowWidgetEnabled=4;
}
void funcSelectWidget::showSub4()
{
    beidou.setTitle(QString("北斗用户机供电"));
    beidou.show();
    beidou.initFocus();
    nowWidgetEnabled=5;
}
void funcSelectWidget::showSub5()
{
    oxygen.setTitle(QString("制氧装置供电"));
    oxygen.show();
    oxygen.initFocus();
    nowWidgetEnabled=6;
}
void funcSelectWidget::showSub6()
{
    wind.setTitle(QString("地面测风供电"));
    wind.show();
    wind.initFocus();
    nowWidgetEnabled=7;
}
void funcSelectWidget::showSub7()
{
    radar.setTitle(QString("测风雷达供电"));
    radar.show();
    radar.initFocus();
    nowWidgetEnabled=8;
}
void funcSelectWidget::showSub8()
{
    firer.setTitle(QString("装定发火器供电"));
    firer.show();
    firer.initFocus();
    nowWidgetEnabled=9;
}
void funcSelectWidget::showSub9()
{
    elecctl.setTitle(QString("电控箱供电"));
    elecctl.show();
    elecctl.initFocus();
    nowWidgetEnabled=10;
}
void funcSelectWidget::showSub10()
{
    servo.setTitle(QString("随动供电"));
    servo.show();
    servo.initFocus();
    nowWidgetEnabled=11;
}
void funcSelectWidget::showSub11()
{
    power.setTitle(QString("动力电源箱供电"));
    power.show();
    power.initFocus();
    nowWidgetEnabled=12;
}


void funcSelectWidget::Insmod_moudles()
{
         fd = ::open("/dev/sam9g45", O_RDWR|O_NONBLOCK);
         if (fd < 0) {
            // QMessageBox::information(&w, "error", "fail to open");
         }

         qDebug("Insmod_moudles_ok\r\n");
}

void funcSelectWidget::Button_action()
{
    if(nowWidgetEnabled==1)
    {
        if(k.at(K_UP)=='0')
        {
            nowWidgetEnabled=0;
            emit switchToMainWidget();
        }
        if(k.at(K_DOWN)=='0')
        {
            this->focusNextChild();

            fw_counter++;
            if(fw_counter==12) fw_counter=0;
            if(fw_counter==-1) fw_counter=11;
            qDebug()<<fw_counter;
        }
        if(k.at(K_LEFT)=='0')
        {
            this->focusPreviousChild();

            fw_counter--;

            if(fw_counter==12) fw_counter=0;
            if(fw_counter==-1) fw_counter=11;
            qDebug()<<fw_counter;
        }
        if(k.at(K_RIGHT)=='0')
        {
            this->focusNextChild();

            fw_counter++;

            if(fw_counter==12) fw_counter=0;
            if(fw_counter==-1) fw_counter=11;
            qDebug()<<fw_counter;
        }
        if(k.at(K_OK)=='0')
        {

            switch (fw_counter) {
            case 1:
                showSub1();
                this->hide();
                break;
            case 2:
                showSub2();
                this->hide();
                break;
            case 3:
                showSub3();
                this->hide();
                break;
            case 4:
                showSub4();
                this->hide();
                break;
            case 5:
                showSub5();
                this->hide();
                break;
            case 6:
                showSub6();
                this->hide();
                break;
            case 7:
                showSub7();
                this->hide();
                break;
            case 8:
                showSub8();
                this->hide();
                break;
            case 9:
                showSub9();
                this->hide();
                break;
            case 10:
                showSub10();
                this->hide();
                break;
            case 11:
                showSub11();
                this->hide();
                break;
            default:
                break;
            }
        }


    }
         //qDebug("Time Total:%d ",timeTotal);
         //qDebug("buf = 0x%x from fw",buf_read);
}

void funcSelectWidget::writeIO()
{

         pdata data_to_kernel;
         data_to_kernel.offset = 17;
         data_to_kernel.dataBuf = 0xffff;

         ret = ioctl(fd, 1, (unsigned long)&data_to_kernel);
         if(ret < 0) {
             //QMessageBox::information(&w, "error", "ioctl");
             return;
         }

}

void funcSelectWidget::dataDisplay()
{
         QByteArray procOutput;
         procOutput = proc.readAll();
         // sysPowerLabel->setText(procOutput.data());
}



