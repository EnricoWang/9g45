#include "mainwidget.h"
#include "main.h"
#include "funcselectwidget.h"

/* 全局变量的实现 */
QDateTime timeStart;
int timeTotal;
QString timePast;
pdata data_to_kernel;
short buf_read;
int nowWidgetEnabled;
QByteArray outState;
QByteArray k;

int main(int argc, char *argv[])
{
    //添加插件路径
    QCoreApplication::addLibraryPath("/usr/local/Trolltech/QtEmbedded-4.7.1-arm/plugins");
    QApplication a(argc, argv);
    timeStart = QDateTime::currentDateTime();
    timeTotal = 0;

    //设置标题栏和字体
    QWSServer::setCursorVisible(false);
    QTextCodec::setCodecForCStrings(QTextCodec::codecForName("UTF-8"));
    QTextCodec::setCodecForLocale(QTextCodec::codecForName("UTF-8"));
    QTextCodec::setCodecForTr(QTextCodec::codecForName("UTF-8"));
    QFont font;
    font.setFamily("wenquanyi");
    font.setPointSize(20);


    QFile file("electime.dat");
    /* 打开文件，读取已运行总时间 */
    if(file.open(QIODevice::ReadOnly))
    {
        QDataStream in(&file);
        in.setVersion(QDataStream::Qt_4_7);
        in >> timePast;
        char* ch;
        QByteArray ba = timePast.toLatin1();
        ch=ba.data();
        qDebug("electime.dat found.The content is as follow:");
        qDebug(ch);
    }
    else    // 若文件不存在，则设置时间为 0
    {
        timePast = "0";
        qDebug("electime.dat not found. 'timePast' was set 0s.");
    }
    if(file.isOpen()) file.close();

    outState.clear();
    outState.append("1111");  //初始化

    MainWidget w;
    w.show();
    nowWidgetEnabled = 0;

    return a.exec();
}

