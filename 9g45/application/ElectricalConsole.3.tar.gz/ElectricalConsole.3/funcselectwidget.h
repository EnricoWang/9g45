#ifndef FUNCSELECTWIDGET_H
#define FUNCSELECTWIDGET_H

#include "main.h"
#include "subwidget.h"

class funcSelectWidget : public QWidget
{
    Q_OBJECT
public:
    explicit funcSelectWidget(QWidget *parent = 0);
    void initFocus();

private:
    SubWidget tpw;
    SubWidget radio;
    SubWidget control;
    SubWidget beidou;
    SubWidget oxygen;
    SubWidget wind;
    SubWidget radar;
    SubWidget firer;
    SubWidget elecctl;
    SubWidget servo;
    SubWidget power;
    int counter;
    int fw_counter;

    QLabel *title;   // 标题：功能选择
    QPushButton *btn1;  //炮长终端
    QPushButton *btn2;  //电台
    QPushButton *btn3;  //通控
    QPushButton *btn4;  //北斗用户机
    QPushButton *btn5;  //制氧装置
    QPushButton *btn6;  //地面测风
    QPushButton *btn7;  //测风雷达
    QPushButton *btn8;  //装定发火器
    QPushButton *btn9;  //电控箱
    QPushButton *btn10;  //随动
    QPushButton *btn11;  //动力电源箱
    QLabel *instruction;  // 操作说明

    void initGUI();     //初始化图形界面

    QTimer *fwTimerButton;
    void Insmod_moudles();     //加载驱动
    void writeIO();
    QProcess proc;
    QStringList arguments;


protected:
    void paintEvent(QPaintEvent *);
signals:
    void switchToMainWidget();  // 切换到主界面
    void switchToTpwWidget(bool);  // 切换到子界面
    void setSubTitle(QString);     // 设置子界面标题

public slots:
    //void setSubVisible();   // 显示或隐藏子界面
    void Button_action();     //更新按钮状态
    void dataDisplay();
    void showSub1();
    void showSub2();
    void showSub3();
    void showSub4();
    void showSub5();
    void showSub6();
    void showSub7();
    void showSub8();
    void showSub9();
    void showSub10();
    void showSub11();
private:
    int fd;
    int ret;

};

#endif // FUNCSELECTWIDGET_H
