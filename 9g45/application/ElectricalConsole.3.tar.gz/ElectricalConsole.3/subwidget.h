#ifndef TERMINALPOWERWIDGET_H
#define TERMINALPOWERWIDGET_H

#include <QObject>
#include <QWidget>
#include <QLabel>
#include<QLineEdit>
#include<QColor>
#include<QPainter>
#include<QDateTime>
#include<QTimer>
#include<QEvent>
#include<QKeyEvent>
#include<QGraphicsEllipseItem>
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QString>
#include <QPushButton>

#include "main.h"

class SubWidget : public QWidget
{
    Q_OBJECT

public:
    explicit SubWidget(QWidget *parent = 0);
    void setTitle(QString s);
    void initFocus();
protected:
    void paintEvent(QPaintEvent *);

private:
    QLabel *title;
    QLabel *status;
    QLabel *operation;

    QLabel *status1;
    QLabel *status2;
    QLabel *status3;
    QLabel *status4;
    QLabel *status5;
    QLabel *status6;

    QGraphicsScene *scene;
    QGraphicsView *view;
    QGraphicsEllipseItem *ellipse1;
    QGraphicsEllipseItem *ellipse2;
    QGraphicsEllipseItem *ellipse3;
    QGraphicsEllipseItem *ellipse4;
    QGraphicsEllipseItem *ellipse5;
    QGraphicsEllipseItem *ellipse6;

    QPushButton *btn1;
    QPushButton *btn2;
    QPushButton *btn3;

    QLabel *instruction;

    QPen pen;
    QPen penGreen;
    QPen penRed;
    QBrush brushRed;
    QBrush brushGreen;
    QBrush brushBlue;
    QColor rgb_background;

     bool  isLEDActive[7];                  // 1-6存状态，0不用
    void initGUI();
    void enableLED(int);
    void disableLED(int);


    int sub_counter;

    QTimer *subTimerButton;
    void Insmod_moudles();     //加载驱动
    void writeIO();
    QProcess proc;
    QStringList arguments;

signals:
    void switchToFwWidget();  // 切换

public slots:
    void setLED(int index,bool isActive);   // 设置编号为index的LED灯的激活状态

    void Button_action();     //更新按钮状态
    void dataDisplay();

private:
    int fd;
    int ret;
};

#endif // TERMINALPOWERWIDGET_H
