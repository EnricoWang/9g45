#ifndef MAINWIDGET_H
#define MAINWIDGET_H

#include "main.h"
#include "canreadthread.h"
#include "funcselectwidget.h"



class MainWidget : public QWidget
{
    Q_OBJECT

public:
    MainWidget(QWidget *parent = 0);
    ~MainWidget();

private:
   funcSelectWidget fw;
    /* 电源电压 */
    QLabel *sysPowerLabel;
    QLabel *forcePowerLabel;
    QLabel *sysPowerStatus;
    QLabel *forcePowerStatus;

    /* 弹箱及其状态 */
    QLabel *ammunitionBox;
    QLabel *ammunitionBoxStatus1;
    QLabel *ammunitionBoxStatus2;
    QLabel *ammunitionBoxStatus3;
    QLabel *ammunitionBoxStatus4;

    /* 电连接器及其状态 */
    QLabel *electricConnector;
    QLabel *electricConnectorStatus1;
    QLabel *electricConnectorStatus2;
    QLabel *electricConnectorStatus3;

    /* 行军固定器及其状态 */
    QLabel *marchFixture;
    QLabel *marchFixtureStatus1;
    QLabel *marchFixtureStatus2;
    QLabel *marchFixtureStatus3;

    /* 气源压力及其状态 */
    QLabel *gasPressure;
    QLabel *gasPressureStatus1;
    QLabel *gasPressureStatus2;

    /* 射击范围及其状态 */
    QLabel *shootRange;
    QLabel *shootRangeStatus1;
    QLabel *shootRangeStatus2;

    /* 其他 */
    QLabel *instruction;
    QLabel *powerSupplyLabel;

    QLabel *timeToNowLabel;
    QTimer *timerForTimeUpdate;
    QTimer *timerForBlink1;
    QTimer *timerButton;

    QKeyEvent *keyPressed;

    /* 以下用于绘制二维图形 */
    QGraphicsView *ledView1;
    QGraphicsView *ledView2;
    QGraphicsView *ledView3;
    QGraphicsView *ledView4;
    QGraphicsView *ledView5;
    QGraphicsScene *ledScene1;
    QGraphicsScene *ledScene2;
    QGraphicsScene *ledScene3;
    QGraphicsScene *ledScene4;
    QGraphicsScene *ledScene5;
    QGraphicsEllipseItem *ellipse1;
    QGraphicsEllipseItem *ellipse2;
    QGraphicsEllipseItem *ellipse3;
    QGraphicsEllipseItem *ellipse4;
    QGraphicsEllipseItem *ellipse5;
    QGraphicsEllipseItem *ellipse6;
    QGraphicsEllipseItem *ellipse7;
    QGraphicsEllipseItem *ellipse8;
    QGraphicsEllipseItem *ellipse9;
    QGraphicsEllipseItem *ellipse10;
    QGraphicsEllipseItem *ellipse11;
    QGraphicsEllipseItem *ellipse12;
    QGraphicsEllipseItem *ellipse13;
    QGraphicsEllipseItem *ellipse14;

    int lastTimeTotal;
    int counterForBlink1;                   //计数器
    int counterforwidget;
    /* 定义画笔颜色和填充颜色 */
    QPen pen;
    QPen penGreen;
    QPen penRed;
    QBrush brushRed;
    QBrush brushGreen;
    QBrush brushBlue;
    QColor rgb_background;

    CanReadThread *canRxThread;
    bool  isLEDActive[15];                  // 1-14存状态，0不用

    void initGUI();                         // 初始化图形界面
    void enableLED(int i);
    void disableLED(int i);
    void insmod_moudles();                  //加载驱动
    void writeIO(unsigned short);           // 整体操作IO
    void writeOutDev(int,bool);             // 按位操作IO

    QProcess proc_canr1;
    QProcess proc_cans1;
    QProcess proc_canr2;
    QProcess proc_cans2;
    QStringList arguments1;
    QStringList arguments2;
    QStringList arguments3;
    QStringList arguments4;
    int canr1counter;
    int canr2counter;
    void showFw();

protected:
    void paintEvent(QPaintEvent *);

signals:
    void switchToFw();                  // 转到功能选择界面
    void can1_send_data(QStringList);

public slots:
    void timeToNowUpdate();                 // 更新系统累计运行时间标签

    /* LED序号从左到右，从上到下依次编号为1-14.其中4、7、10、12、14号为红灯 */
    void setLED(int index,bool isActive);   // 设置编号为index的LED灯的激活状态
    void setSysPower(float voltage);        // 设置系统电源电压值
    void setForcePower(float voltage);      // 设置动力电源电压值
    void setPowerSupplyLabel(QString s,bool isGood);  // 设置右下角供电状态标签
    void keyPressEvent(QKeyEvent *event);
    void blinkLEDRed();                     // 使被激活的红色LED灯闪烁

    void Button_state();     //更新按钮状态
    void Button_action();
    void dataDisplay1();
    void dataDisplay2();


    void can1_send(QStringList);
    void can2_send(QStringList);

private:
    int fd;
    int ret;
};

#endif // MAINWIDGET_H
