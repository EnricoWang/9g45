/****************************************************************************
** Meta object code from reading C++ file 'mainwidget.h'
**
** Created: Tue Oct 13 16:00:31 2015
**      by: The Qt Meta Object Compiler version 62 (Qt 4.7.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "mainwidget.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.7.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_MainWidget[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
      15,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: signature, parameters, type, tag, flags
      12,   11,   11,   11, 0x05,
      25,   11,   11,   11, 0x05,

 // slots: signature, parameters, type, tag, flags
      53,   11,   11,   11, 0x0a,
      86,   71,   11,   11, 0x0a,
     111,  103,   11,   11, 0x0a,
     130,  103,   11,   11, 0x0a,
     160,  151,   11,   11, 0x0a,
     200,  194,   11,   11, 0x0a,
     226,   11,   11,   11, 0x0a,
     240,   11,   11,   11, 0x0a,
     255,   11,   11,   11, 0x0a,
     271,   11,   11,   11, 0x0a,
     286,   11,   11,   11, 0x0a,
     301,   11,   11,   11, 0x0a,
     324,   11,   11,   11, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_MainWidget[] = {
    "MainWidget\0\0switchToFw()\0"
    "can1_send_data(QStringList)\0"
    "timeToNowUpdate()\0index,isActive\0"
    "setLED(int,bool)\0voltage\0setSysPower(float)\0"
    "setForcePower(float)\0s,isGood\0"
    "setPowerSupplyLabel(QString,bool)\0"
    "event\0keyPressEvent(QKeyEvent*)\0"
    "blinkLEDRed()\0Button_state()\0"
    "Button_action()\0dataDisplay1()\0"
    "dataDisplay2()\0can1_send(QStringList)\0"
    "can2_send(QStringList)\0"
};

const QMetaObject MainWidget::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_MainWidget,
      qt_meta_data_MainWidget, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MainWidget::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MainWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MainWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MainWidget))
        return static_cast<void*>(const_cast< MainWidget*>(this));
    return QWidget::qt_metacast(_clname);
}

int MainWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: switchToFw(); break;
        case 1: can1_send_data((*reinterpret_cast< QStringList(*)>(_a[1]))); break;
        case 2: timeToNowUpdate(); break;
        case 3: setLED((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 4: setSysPower((*reinterpret_cast< float(*)>(_a[1]))); break;
        case 5: setForcePower((*reinterpret_cast< float(*)>(_a[1]))); break;
        case 6: setPowerSupplyLabel((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 7: keyPressEvent((*reinterpret_cast< QKeyEvent*(*)>(_a[1]))); break;
        case 8: blinkLEDRed(); break;
        case 9: Button_state(); break;
        case 10: Button_action(); break;
        case 11: dataDisplay1(); break;
        case 12: dataDisplay2(); break;
        case 13: can1_send((*reinterpret_cast< QStringList(*)>(_a[1]))); break;
        case 14: can2_send((*reinterpret_cast< QStringList(*)>(_a[1]))); break;
        default: ;
        }
        _id -= 15;
    }
    return _id;
}

// SIGNAL 0
void MainWidget::switchToFw()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}

// SIGNAL 1
void MainWidget::can1_send_data(QStringList _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
QT_END_MOC_NAMESPACE
