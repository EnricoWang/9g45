#include"main.h"

void readIO()
{
    int fd;
    int ret;

    buf_read = 0;

    data_to_kernel.offset = 16;
    data_to_kernel.dataBuf = 0;

    ret = ioctl(fd, 3, (unsigned long)&data_to_kernel);
    if(ret < 0) {
        //QMessageBox::information(&w, "error", "ioctl");
        return;
    }
    ret = read(fd, &buf_read, 2);

    if(ret < 0){
        //QMessageBox::information(&w, "error", "read");
        return;
    }
    //qDebug("buf = 0x%x from main", buf_read);
}


void writeIO(unsigned short data)
{
    int fd;
    int ret;
    pdata data_write;
    data_write.offset = 17;
    data_write.dataBuf = data;

    ret = ioctl(fd, 1, (unsigned long)&data_write);

    if(ret < 0) {
        qDebug("writeIO ERROR.");
        return;
    }
    else qDebug("writeIO OK. data=0x%x",data);

}
