/****************************************************************************
** Meta object code from reading C++ file 'canreadthread.h'
**
** Created: Tue Oct 13 16:00:30 2015
**      by: The Qt Meta Object Compiler version 62 (Qt 4.7.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "canreadthread.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'canreadthread.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.7.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_CanReadThread[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       5,       // signalCount

 // signals: signature, parameters, type, tag, flags
      17,   15,   14,   14, 0x05,
      40,   14,   14,   14, 0x05,
      66,   14,   14,   14, 0x05,
      94,   15,   14,   14, 0x05,
     129,   15,   14,   14, 0x05,

       0        // eod
};

static const char qt_meta_stringdata_CanReadThread[] = {
    "CanReadThread\0\0,\0isLEDChanged(int,bool)\0"
    "getSysPowerVoltage(float)\0"
    "getForcePowerVoltage(float)\0"
    "getIsPowerSupplyGood(QString,bool)\0"
    "setTpwStatus(int,bool)\0"
};

const QMetaObject CanReadThread::staticMetaObject = {
    { &QThread::staticMetaObject, qt_meta_stringdata_CanReadThread,
      qt_meta_data_CanReadThread, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &CanReadThread::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *CanReadThread::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *CanReadThread::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_CanReadThread))
        return static_cast<void*>(const_cast< CanReadThread*>(this));
    return QThread::qt_metacast(_clname);
}

int CanReadThread::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QThread::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: isLEDChanged((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 1: getSysPowerVoltage((*reinterpret_cast< float(*)>(_a[1]))); break;
        case 2: getForcePowerVoltage((*reinterpret_cast< float(*)>(_a[1]))); break;
        case 3: getIsPowerSupplyGood((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 4: setTpwStatus((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        default: ;
        }
        _id -= 5;
    }
    return _id;
}

// SIGNAL 0
void CanReadThread::isLEDChanged(int _t1, bool _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void CanReadThread::getSysPowerVoltage(float _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void CanReadThread::getForcePowerVoltage(float _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void CanReadThread::getIsPowerSupplyGood(QString _t1, bool _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void CanReadThread::setTpwStatus(int _t1, bool _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}
QT_END_MOC_NAMESPACE
