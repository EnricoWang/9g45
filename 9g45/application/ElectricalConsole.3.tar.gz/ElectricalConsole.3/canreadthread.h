#ifndef CANREADTHREAD_H
#define CANREADTHREAD_H

#include <QObject>
#include <QThread>
#include <QTimer>
#include <QTime>
#include <QSocketNotifier>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <net/if.h>
#include <sys/socket.h>
#include <sys/uio.h>

#define PF_CAN 29
class CanReadThread : public QThread
{
    Q_OBJECT

public:
    CanReadThread(QObject *parent = 0);
    void stop();


signals:
    void isLEDChanged(int,bool);  //LED灯状态发生改变
    void getSysPowerVoltage(float);
    void getForcePowerVoltage(float);
    void getIsPowerSupplyGood(QString,bool);

    void setTpwStatus(int,bool);


protected:
    void run();

private:
    volatile bool stopped;
    float sysPowerVoltage;
    float forcePowerVoltage;
    bool  isLEDActive[15];       // 1-14存状态，0不用
    QString powerSupplyStatus;  // 显示供电状态处的文字
    bool isPowerSupplyGood;     // 供电是否正常
    QTimer *timer;

private slots:


};



#endif // CANREADTHREAD_H





