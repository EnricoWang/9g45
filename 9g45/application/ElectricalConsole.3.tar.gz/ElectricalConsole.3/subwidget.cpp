#include "subwidget.h"

SubWidget::SubWidget(QWidget *parent)
    : QWidget(parent)
{
    //设置鼠标和大小
    Qt::WindowFlags flags=0;
    flags |= Qt::FramelessWindowHint;//
    //this->setAttribute(Qt::WA_DeleteOnClose);
    //this->setWindowFlags(flags);
    this->setFixedSize(160,120);
    QPalette pe_background;
    QColor rgb_background;
    rgb_background.setRgb(209,212,152);
    pe_background.setColor(QPalette::WindowText,rgb_background);
    this->setStyleSheet("color:yellow; background-color:rgb(15,59,92)");
    initGUI();

    sub_counter=0;

    subTimerButton = new QTimer(this);
    connect(subTimerButton, SIGNAL(timeout()), this, SLOT(Button_action()));
    subTimerButton->start(200);
}

void SubWidget::initGUI()
{

    status= new QLabel(this);
    status->setText("状 态");
    status->setAlignment(Qt::AlignCenter);
    status->setGeometry(116,40,100,20);

    operation= new QLabel(this);
    operation->setText("操 作");
    operation->setAlignment(Qt::AlignCenter);
    operation->setGeometry(116,117,100,20);

    btn1= new QPushButton(this);
    btn1->setText("接通");
    btn1->setGeometry(45,147,60,30);
    btn1->setStyleSheet("background:#007503");

    btn2= new QPushButton(this);
    btn2->setText("关断");
    btn2->setGeometry(135,147,60,30);
    btn2->setStyleSheet("background:#007503");

    btn3= new QPushButton(this);
    btn3->setText("复位");
    btn3->setGeometry(225,147,60,30);
    btn3->setStyleSheet("background:#007503");

    instruction= new QLabel(this);
    instruction->setText("  按“左”、“右”、“下”移动光标，按“确认”\n执行操作，按“上”返回上一层");
    instruction->setGeometry(20,195,280,35);
    instruction->setAlignment(Qt::AlignLeft);

    status1= new QLabel(this);
    status1->setText("通路");
    status1->setStyleSheet("color:rgb(242,210,40)");
    status1->setGeometry(38,80,30,20);
    status1->setAlignment(Qt::AlignCenter);

    status2= new QLabel(this);
    status2->setText("断路");
    status2->setStyleSheet("color:rgb(242,210,40)");
    status2->setGeometry(83,80,30,20);
    status2->setAlignment(Qt::AlignCenter);

    status3= new QLabel(this);
    status3->setText("过流");
    status3->setStyleSheet("color:rgb(242,210,40)");
    status3->setGeometry(128,80,30,20);
    status3->setAlignment(Qt::AlignCenter);

    status4= new QLabel(this);
    status4->setText("过压");
    status4->setStyleSheet("color:rgb(242,210,40)");
    status4->setGeometry(173,80,30,20);
    status4->setAlignment(Qt::AlignCenter);

    status5= new QLabel(this);
    status5->setText("短路");
    status5->setStyleSheet("color:rgb(242,210,40)");
    status5->setGeometry(218,80,30,20);
    status5->setAlignment(Qt::AlignCenter);

    status6= new QLabel(this);
    status6->setText("过热");
    status6->setStyleSheet("color:rgb(242,210,40)");
    status6->setGeometry(263,80,30,20);
    status6->setAlignment(Qt::AlignCenter);

    scene = new QGraphicsScene(this);

    QPalette p;
    p.setColor(QPalette::WindowText,Qt::transparent);
    pen.setColor(Qt::black);
    pen.setWidth(0.35);
    pen.setCapStyle(Qt::RoundCap);
    pen.setStyle(Qt::SolidLine);
    penGreen.setColor(Qt::green);
    penGreen.setWidth(0.35);
    penGreen.setCapStyle(Qt::RoundCap);
    penGreen.setStyle(Qt::SolidLine);
    penRed.setColor(Qt::red);
    penRed.setWidth(0.35);
    penRed.setCapStyle(Qt::RoundCap);
    penRed.setStyle(Qt::SolidLine);
    brushRed.setColor(Qt::red);
    brushRed.setStyle(Qt::SolidPattern);
    brushGreen.setColor(Qt::green);
    brushGreen.setStyle(Qt::SolidPattern);
    QColor rgb_background;
    rgb_background.setRgb(15,59,92);
    brushBlue.setColor(rgb_background); //与背景色相同
    brushBlue.setStyle(Qt::SolidPattern);

    view = new QGraphicsView(this);
    view->setGeometry(17,68,320,13);
    view->setPalette(p);
    view->setFrameStyle(0); //不显示边框
    view->setScene(scene);
    view->setSceneRect(0,0,320,13);
    view->setStyleSheet("background:transparent");

    ellipse1 = new QGraphicsEllipseItem();
    ellipse1->setRect(30,2,10,10);
    ellipse1->setPen(pen);
    ellipse1->setBrush(brushGreen);

    ellipse2 = new QGraphicsEllipseItem();
    ellipse2->setRect(75,2,10,10);
    ellipse2->setPen(pen);
    ellipse2->setBrush(brushRed);

    ellipse3 = new QGraphicsEllipseItem();
    ellipse3->setRect(120,2,10,10);
    ellipse3->setPen(pen);
    ellipse3->setBrush(brushRed);

    ellipse4 = new QGraphicsEllipseItem();
    ellipse4->setRect(165,2,10,10);
    ellipse4->setPen(pen);
    ellipse4->setBrush(brushRed);

    ellipse5 = new QGraphicsEllipseItem();
    ellipse5->setRect(210,2,10,10);
    ellipse5->setPen(pen);
    ellipse5->setBrush(brushRed);

    ellipse6 = new QGraphicsEllipseItem();
    ellipse6->setRect(255,2,10,10);
    ellipse6->setPen(pen);
    ellipse6->setBrush(brushRed);

    enableLED(1);
    enableLED(2);
    enableLED(3);
    enableLED(4);
    enableLED(5);
    enableLED(6);
}

void SubWidget::initFocus()
{
    this->setFocus();
    sub_counter=0;
}

void SubWidget::setTitle(QString s)
{
    title= new QLabel(this);
    title->setAlignment(Qt::AlignCenter);
    title->setGeometry(117,7,100,20);
    title->setText(s);
}

void SubWidget::setLED(int index,bool isActive)
{
    isLEDActive[index]=isActive;
    if(isActive) enableLED(index);
    else disableLED(index);
}

void SubWidget::enableLED(int i)
{
    switch(i)
    {
        case 1:
            scene->addItem(ellipse1); break;
        case 2:
            scene->addItem(ellipse2); break;
        case 3:
            scene->addItem(ellipse3); break;
        case 4:
            scene->addItem(ellipse4); break;
        case 5:
            scene->addItem(ellipse5); break;
        case 6:
            scene->addItem(ellipse6); break;
    }

}
void SubWidget::disableLED(int i)
{
    switch(i)
    {

        case 1:
            scene->removeItem(ellipse1); break;
        case 2:
            scene->removeItem(ellipse2); break;
        case 3:
            scene->removeItem(ellipse3); break;
        case 4:
            scene->removeItem(ellipse4); break;
        case 5:
            scene->removeItem(ellipse5); break;
        case 6:
            scene->removeItem(ellipse6); break;
    }
}
void SubWidget::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QColor line;
    line.setRgb(41,182,23);
    painter.setPen(QPen(Qt::gray,3,Qt::SolidLine,Qt::RoundCap));

    // line to seperate different parts
    painter.drawLine(1,1,317,1);    // horizontal
    painter.drawLine(1,236,317,236);    // horizontal
    painter.drawLine(1,35,320,35);    // horizontal
    painter.drawLine(1,110,320,110);  // horizontal
    painter.drawLine(1,185,320,185);  // horizontal
    painter.drawLine(1,0,1,237); // vertical
    painter.drawLine(319,0,319,237); // vertical
}
/*
void SubWidget::Insmod_moudles()
{
         fd = ::open("/dev/sam9g45", O_RDWR|O_NONBLOCK);
         if (fd < 0) {
            // QMessageBox::information(&w, "error", "fail to open");
         }

         qDebug("Insmod_moudles_ok\r\n");
}
*/

void SubWidget::Button_action()
{
  if( nowWidgetEnabled > 1 )
  {
    if(k.at(K_UP)=='0')
    {
        this->setFocus();
        //this->clearFocus();
        /* 切换后将按键状态置为1，防止功能选择界面误读而直接调转至主界面 */
        QByteArray ba1("1");
        k.replace(K_UP,1,ba1);
        nowWidgetEnabled=1;
        emit switchToFwWidget();
        this->hide();
 //       qDebug("hide");
    }
    if(k.at(K_DOWN)=='0')
    {
        this->focusNextChild();
        sub_counter++;
        if(sub_counter==4) sub_counter=0;
        if(sub_counter==-1) sub_counter=3;
    }
    if(k.at(K_LEFT)=='0')
    {
        this->focusPreviousChild();
        sub_counter--;
        if(sub_counter==4) sub_counter=0;
        if(sub_counter==-1) sub_counter=3;
    }
    if(k.at(K_RIGHT)=='0')
    {
        this->focusNextChild();
        sub_counter++;
        if(sub_counter==4) sub_counter=0;
        if(sub_counter==-1) sub_counter=3;
    }
    if(k.at(K_OK)=='0')
    {
    }
  }
}

void SubWidget::writeIO()
{

         pdata data_to_kernel;
         data_to_kernel.offset = 17;
         data_to_kernel.dataBuf = 0xffff;

         ret = ioctl(fd, 1, (unsigned long)&data_to_kernel);
         if(ret < 0) {
             //QMessageBox::information(&w, "error", "ioctl");
             return;
         }

}

void SubWidget::dataDisplay()
{
         QByteArray procOutput;
         procOutput = proc.readAll();
         // sysPowerLabel->setText(procOutput.data());

         // 输出读到的数据
         //qDebug() << procOutput.data();
         //添加界面显示代码
         //for example
         //ui->LineEdit->setText(procOutput.data());
}

