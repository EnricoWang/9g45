#ifndef MAIN_H
#define MAIN_H

#include <QWidget>
#include <QLabel>
#include<QLineEdit>
#include<QColor>
#include<QPainter>
#include<QDateTime>
#include<QTimer>
#include<QEvent>
#include<QKeyEvent>
#include<QGraphicsEllipseItem>
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QObject>
#include <QString>
#include <QFile>
#include <QMessageBox>
#include <QProcess>
#include <QStringList>
#include <QDebug>
#include <QByteArray>

#include <QApplication>
#include <QWSServer>
#include <QTextCodec>
#include <QFont>
#include <QFileOpenEvent>
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <linux/input.h>

#define K_UP  11     //0xfffffffe
#define K_DOWN  10   //0xfffffffd
#define K_LEFT   9   //0xfffffffb
#define K_RIGHT  8   //0xfffffff7
#define K_FUNC  7    //0xffffffef
#define K_OK  6      //0xffffffdf
#define K_USE  5     //0xffffffbf   用炮键
#define K_UNUSE  4   //0xffffff7f   收炮键

#define K_AUTO  2      //0xfffffdff   自动1、半自动0
#define K_CONNECT 1    //0xfffffbff   弹箱电连接器连接1、断开0
#define K_ALARM 3      //0xfffffeff   报警按下为1，弹起为0

#define OUT_ALARM 0     //0xf7ff   蜂鸣器
#define OUT_ALARM_LED 1 //0xfbff   报警灯
#define OUT_USE 3       //0xfeff   用炮灯
#define OUT_UNUSE 2     //0xfdff   收炮灯

//void readIO();
//void writeIO(unsigned short);

extern QDateTime timeStart;
extern QString timePast; //开机之前已运行的时间，单位为秒
extern int timeTotal; //本次开机已运行的时间，单位为秒

extern short buf_read;

extern int nowWidgetEnabled; // 当前激活的窗口编号

extern QByteArray outState;  // 输出设备的状态（4位二进制）
extern QByteArray k;   // 按键状态,截取后8位（对应面板上的8个按键）

typedef struct __fpga_pdata {
    int offset;
    unsigned short dataBuf;
}pdata;
extern pdata data_to_kernel;
#endif // MAIN_H

